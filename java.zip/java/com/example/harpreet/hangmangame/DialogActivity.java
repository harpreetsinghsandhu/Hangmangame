package com.example.harpreet.hangmangame;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class DialogActivity extends AppCompatActivity {
TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialog);

        setTitle("");
        tv=(TextView)(findViewById(R.id.tvsuggest));
        Intent in=getIntent();
        String suggest=in.getStringExtra("suggest");
        tv.setText(suggest);


    }
    public void hide(View view)
    {

     finish();
    }
}
