package com.example.harpreet.hangmangame;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

public class MissionFailDialogActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mission_fail_dialog);
        setTitle("");
    }
    public void previouspage(View view)
    {
        Intent in = new Intent();
        in.putExtra("value",1);

        setResult(RESULT_OK,in);
        finish();
    }
    public void nextword(View view){
        Intent in = new Intent();
        in.putExtra("value",2);

        setResult(RESULT_OK,in);
        finish();
    }
}
