package com.example.harpreet.hangmangame;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

public class MissionSuccessDialogActivity extends AppCompatActivity {
    ImageView img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mission_success_dialog);


//        ActionBar supportActionBar = getSupportActionBar();
//
//        Log.d("VmmEducation", supportActionBar + "");
//        if (supportActionBar != null) {
//            supportActionBar.hide();
//        }
        setTitle("");

        img = (ImageView) (findViewById(R.id.imv));

        Intent in = getIntent();
        int photo = in.getIntExtra("photo", 0);
        img.setImageResource(photo);
        Picasso.with(getApplicationContext()).load(photo).resize(200, 200).centerInside().into(img);
    }

    public void previouspage(View view) {
        Intent in = new Intent();
        in.putExtra("value", 1);

        setResult(RESULT_OK, in);
        finish();
    }

    public void nextword(View view) {
        Intent in = new Intent();
        in.putExtra("value", 2);

        setResult(RESULT_OK, in);
        finish();
    }
}
