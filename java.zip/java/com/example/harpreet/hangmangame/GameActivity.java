package com.example.harpreet.hangmangame;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class GameActivity extends AppCompatActivity {
    String cname = "";
    TextView tvcat, tvscore;
    TextToSpeech t1;
    ImageView img;
    Button bt1, bt2, bt3, bt4, bt5, bt6, bt7, bt8, bt9, bt10, bt11, bt12, bt13, bt14, bt15, bt16, bt17, bt18, bt19, bt20, bt21, bt22, bt23, bt24, bt25, bt26;
    ArrayList<gamewords> al;
    ArrayList<TextView> altv;
    AlertDialog.Builder ad,adover,adp;
    LinearLayout answerLinearlayout;
    int wordlength = 0;
    String word = "";
    String suggest = "";
    int photo;
    char answer[];
    int score = 0;
    int correctlytyped = 0;
    int wronglytyped = 0;
    int currentwordindex = 0;
    SQLiteDatabase db;
    View alphaColorView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_game);
        alphaColorView = (View) findViewById(R.id.alphaColorView);
        alphaColorView.setBackgroundColor(getColorWithAlpha(Color.YELLOW, 0.5f));
        Intent in = getIntent();
        cname = in.getStringExtra("cname");
       initiallogic();
    }
    public static int getColorWithAlpha(int color,float ratio)
    {
        int newColor = 0;
        int alpha = Math.round(Color.alpha(color)*ratio);
        int r=Color.red(color);
        int g=Color.green(color);
        int b= Color.blue(color);
        newColor=Color.argb(alpha,r,g,b);
        return newColor;

    }
    public void initiallogic()
    {
        al = new ArrayList<>();
        altv = new ArrayList<>();
        img=(ImageView)(findViewById(R.id.imghang));
        t1=new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status != TextToSpeech.ERROR) {
                    t1.setLanguage(Locale.UK);
                }
            }
        });
        db = openOrCreateDatabase("MYDB", MODE_PRIVATE, null);
        tvcat = (TextView) (findViewById(R.id.tvcat));
        tvscore = (TextView) (findViewById(R.id.tvscore));
        tvcat.setText(cname);
        db = openOrCreateDatabase("MYDB", MODE_PRIVATE, null);
        Cursor c = db.rawQuery("select * from words where cname='" + cname + "'", null);
        al.clear();
        while (c.moveToNext()) {
            int photo = c.getInt(c.getColumnIndex("photo"));
            String word = c.getString(c.getColumnIndex("word"));
            String suggest = c.getString(c.getColumnIndex("suggest"));
            al.add(new gamewords(word, suggest, photo));
        }

        Cursor cus = db.rawQuery("select * from scoretable", null);
        while(cus.moveToNext()) {
            score = cus.getInt(cus.getColumnIndex("userscore"));

        }
        tvscore.setText("SCORE " + score);
        bt1 = (Button) (findViewById(R.id.bt1));
        bt2 = (Button) (findViewById(R.id.bt2));
        bt3 = (Button) (findViewById(R.id.bt3));
        bt4 = (Button) (findViewById(R.id.bt4));
        bt5 = (Button) (findViewById(R.id.bt5));
        bt6 = (Button) (findViewById(R.id.bt6));
        bt7 = (Button) (findViewById(R.id.bt7));
        bt8 = (Button) (findViewById(R.id.bt8));
        bt9 = (Button) (findViewById(R.id.bt9));
        bt10 = (Button) (findViewById(R.id.bt10));
        bt11 = (Button) (findViewById(R.id.bt11));
        bt12 = (Button) (findViewById(R.id.bt12));
        bt13 = (Button) (findViewById(R.id.bt13));
        bt14 = (Button) (findViewById(R.id.bt14));
        bt15 = (Button) (findViewById(R.id.bt15));
        bt16 = (Button) (findViewById(R.id.bt16));
        bt17 = (Button) (findViewById(R.id.bt17));
        bt18 = (Button) (findViewById(R.id.bt18));
        bt19 = (Button) (findViewById(R.id.bt19));
        bt20 = (Button) (findViewById(R.id.bt20));
        bt21 = (Button) (findViewById(R.id.bt21));
        bt22 = (Button) (findViewById(R.id.bt22));
        bt23 = (Button) (findViewById(R.id.bt23));
        bt24 = (Button) (findViewById(R.id.bt24));
        bt25 = (Button) (findViewById(R.id.bt25));
        bt26 = (Button) (findViewById(R.id.bt26));
        ad = new AlertDialog.Builder(this);
        ad.setTitle("Alert");
        ad.setIcon(R.drawable.icon1);
        ad.setMessage("Do you really want to exit?");
        ad.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                db.execSQL("insert into scoretable (userscore) values(" + score + ")");
                Intent myintent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(myintent);
            }
        });

        ad.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        ad.create();
        adover = new AlertDialog.Builder(this);
        adover.setTitle("Game Over");
        adover.setIcon(R.drawable.icon1);
        adover.setMessage("Do you want to start next game category?");
        adover.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                db.execSQL("insert into scoretable (userscore) values(" + score + ")");
                Intent myintent = new Intent(getApplicationContext(), CategoriesActivity.class);
                startActivity(myintent);
            }
        });

        adover.setNeutralButton("Exit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                db.execSQL("insert into scoretable (userscore) values(" + score + ")");
                Intent myintent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(myintent);
            }
        });
        adover.create();
        adp = new AlertDialog.Builder(this);
        adp.setTitle("Alert");
        adp.setIcon(R.drawable.icon1);
        adp.setMessage("Sorry You don't have enough score To get hint.");
        adp.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        adp.create();
        setnewword(currentwordindex);
    }
    private void setnewword(int index) {
        if (index < al.size()) {
            answerLinearlayout = (LinearLayout) (findViewById(R.id.answerLinearlayout));
            answerLinearlayout.removeAllViews();
            img.setImageResource(R.drawable.hanged);
            bt1.setEnabled(true);bt1.setTextColor(Color.parseColor("#000000"));
            bt2.setEnabled(true);bt2.setTextColor(Color.parseColor("#000000"));
            bt3.setEnabled(true);bt3.setTextColor(Color.parseColor("#000000"));
            bt4.setEnabled(true);bt4.setTextColor(Color.parseColor("#000000"));
            bt5.setEnabled(true);bt5.setTextColor(Color.parseColor("#000000"));
            bt6.setEnabled(true);bt6.setTextColor(Color.parseColor("#000000"));
            bt7.setEnabled(true);bt7.setTextColor(Color.parseColor("#000000"));
            bt8.setEnabled(true);bt8.setTextColor(Color.parseColor("#000000"));
            bt9.setEnabled(true);bt9.setTextColor(Color.parseColor("#000000"));
            bt10.setEnabled(true);bt10.setTextColor(Color.parseColor("#000000"));
            bt11.setEnabled(true);bt11.setTextColor(Color.parseColor("#000000"));
            bt12.setEnabled(true);bt12.setTextColor(Color.parseColor("#000000"));
            bt13.setEnabled(true);bt13.setTextColor(Color.parseColor("#000000"));
            bt14.setEnabled(true);bt14.setTextColor(Color.parseColor("#000000"));
            bt15.setEnabled(true);bt15.setTextColor(Color.parseColor("#000000"));
            bt16.setEnabled(true);bt16.setTextColor(Color.parseColor("#000000"));
            bt17.setEnabled(true);bt17.setTextColor(Color.parseColor("#000000"));
            bt18.setEnabled(true);bt18.setTextColor(Color.parseColor("#000000"));
            bt19.setEnabled(true);bt19.setTextColor(Color.parseColor("#000000"));
            bt20.setEnabled(true);bt20.setTextColor(Color.parseColor("#000000"));
            bt21.setEnabled(true);bt21.setTextColor(Color.parseColor("#000000"));
            bt22.setEnabled(true);bt22.setTextColor(Color.parseColor("#000000"));
            bt23.setEnabled(true);bt23.setTextColor(Color.parseColor("#000000"));
            bt24.setEnabled(true);bt24.setTextColor(Color.parseColor("#000000"));
            bt25.setEnabled(true);bt25.setTextColor(Color.parseColor("#000000"));
            bt26.setEnabled(true);bt26.setTextColor(Color.parseColor("#000000"));
            correctlytyped = 0;
            wronglytyped = 0;
            word = al.get(index).word;
            answer = new char[word.length()];
            suggest = al.get(index).suggest;
            photo = al.get(index).photo;
            wordlength = word.length();
            altv.clear();
            for (int m = 0; m < word.length(); m++) {
                final TextView textView = new TextView(getApplicationContext());
                textView.setLayoutParams(new LinearLayout.LayoutParams(85, 200));
                textView.setPadding(5, 0, 5, 0);
                textView.setGravity(Gravity.BOTTOM);
                textView.setTextSize(25);
                textView.setText("_");
                textView.setTextColor(Color.BLACK);
                altv.add(textView);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        answerLinearlayout.addView(textView);

                    }
                });
            }
            try {
                Intent intent = new Intent(getApplicationContext(), DialogActivity.class);
                intent.putExtra("suggest", suggest);
                startActivity(intent);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            db.execSQL("insert into scoretable (userscore) values(" + score + ")");
            adover.show();
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 10 && resultCode == RESULT_OK) {

            int v = data.getIntExtra("value", 0);
            if (v == 1) {
                db.execSQL("insert into scoretable (userscore) values(" + score + ")");
                Intent myin = new Intent(this, MainActivity.class);
                startActivity(myin);
            } else if (v == 2) {

                if (currentwordindex <= al.size()-1) {
                    currentwordindex++;
                    setnewword(currentwordindex);
                } else {
                    db.execSQL("insert into scoretable (userscore) values(" + score + ")");
                    adover.show();

                }
            }
        }
    }

    public class gamewords {
        String word;
        String suggest;
        int photo;

        public gamewords(String word, String suggest, int photo) {
            this.word = word;
            this.suggest = suggest;
            this.photo = photo;
        }
    }

    public void suggest(View view) {
        try {
            Intent intent = new Intent(getApplicationContext(), DialogActivity.class);
            intent.putExtra("suggest", suggest);
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
public void hint(View view)
{
while(true) {
    if (score > 4) {
        int min = 0;
        int max = wordlength;
        int randomNum = min + (int) (Math.random() * max);

        String t = word.charAt(randomNum) + "";
        t = t.toUpperCase();
        char ch = t.charAt(0);

        boolean flag = false;
        for (int i = 0; i < answer.length - 1; i++) {
            if (answer[i] == ch) {
                flag = true;
            }
        }
        if (flag == false) {
            if (word.toUpperCase().contains(t)) {
                if (correctlytyped == wordlength) {
                    if (currentwordindex < al.size()) {
                        currentwordindex++;
                        setnewword(currentwordindex);
                    } else {
                        db.execSQL("insert into scoretable (userscore) values(" + score + ")");
                        adover.show();
                    }
                } else {
                    int counter1 = 0;
                    int pos[] = new int[50];
                    for (int i = 0; i < word.length(); i++) {
                        if (word.toUpperCase().charAt(i) == ch) {
                            pos[counter1] = i;
                            counter1++;
                        }
                    }
                    for (int i = 0; i < counter1; i++) {
                        int value = pos[i];
                        answer[value] = ch;
                        correctlytyped++;
                        altv.get(value).setText(t);
                        try {
                            Thread.sleep(500);

                        }
                        catch(Exception ex)
                        {
                            ex.printStackTrace();
                        }
                        if (i == counter1 - 1) {
                            if (ch == 'Q') {
                                bt1.setEnabled(false);
                                bt1.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'W') {
                                bt2.setEnabled(false);
                                bt2.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'E') {
                                bt3.setEnabled(false);
                                bt3.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'R') {
                                bt4.setEnabled(false);
                                bt4.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'T') {
                                bt5.setEnabled(false);
                                bt5.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'Y') {
                                bt6.setEnabled(false);
                                bt6.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'U') {
                                bt7.setEnabled(false);
                                bt7.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'I') {
                                bt8.setEnabled(false);
                                bt8.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'O') {
                                bt9.setEnabled(false);
                                bt9.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'P') {
                                bt10.setEnabled(false);
                                bt10.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'A') {
                                bt11.setEnabled(false);
                                bt11.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'S') {
                                bt12.setEnabled(false);
                                bt12.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'D') {
                                bt13.setEnabled(false);
                                bt13.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'F') {
                                bt14.setEnabled(false);
                                bt14.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'G') {
                                bt15.setEnabled(false);
                                bt15.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'H') {
                                bt16.setEnabled(false);
                                bt16.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'J') {
                                bt17.setEnabled(false);
                                bt17.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'K') {
                                bt18.setEnabled(false);
                                bt18.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'L') {
                                bt19.setEnabled(false);
                                bt19.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'Z') {
                                bt20.setEnabled(false);
                                bt20.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'X') {
                                bt21.setEnabled(false);
                                bt21.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'C') {
                                bt22.setEnabled(false);
                                bt22.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'V') {
                                bt23.setEnabled(false);
                                bt23.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'B') {
                                bt24.setEnabled(false);
                                bt24.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'N') {
                                bt25.setEnabled(false);
                                bt25.setTextColor(Color.parseColor("#33cc00"));
                            } else if (ch == 'M') {
                                bt26.setEnabled(false);
                                bt26.setTextColor(Color.parseColor("#33cc00"));
                            }
                            score = score - 5;
                            tvscore.setText("SCORE " + score);
                        }
                        if (correctlytyped == wordlength) {
                           // Toast.makeText(getApplicationContext(), "you win ", Toast.LENGTH_LONG).show();
                            score = score - 5;
                            score = score + 10;
                            tvscore.setText("SCORE " + score);

                                t1.speak(word, TextToSpeech.QUEUE_FLUSH, null);
                                Intent in = new Intent(this, MissionSuccessDialogActivity.class);
                            in.putExtra("photo", photo);
                                startActivityForResult(in, 10);


                        }
                    }
                }
            }
            break;
        }
    } else {
        adp.show();
        break;
    }
}
}
public void buttonlogic(String t,char ch)
{

    if (word.toUpperCase().contains(t)) {
        if (correctlytyped == wordlength) {
            if (currentwordindex < al.size()) {
                currentwordindex++;
                setnewword(currentwordindex);
            } else {
                db.execSQL("insert into scoretable (userscore) values(" + score + ")");
                adover.show();
            }
        } else {
            int counter1 = 0;
            int pos[] = new int[50];
            for (int i = 0; i < word.length(); i++) {
                if (word.toUpperCase().charAt(i) == ch) {
                    pos[counter1] = i;
                    counter1++;
                }
            }

            for (int i = 0; i < counter1; i++) {
                int value = pos[i];
                answer[value] = ch;
                correctlytyped++;
                altv.get(value).setText(t);
                if (i == counter1 - 1) {
                    if (ch == 'Q') {
                        bt1.setEnabled(false);
                        bt1.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'W') {
                        bt2.setEnabled(false);
                        bt2.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'E') {
                        bt3.setEnabled(false);
                        bt3.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'R') {
                        bt4.setEnabled(false);
                        bt4.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'T') {
                        bt5.setEnabled(false);
                        bt5.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'Y') {
                        bt6.setEnabled(false);
                        bt6.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'U') {
                        bt7.setEnabled(false);
                        bt7.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'I') {
                        bt8.setEnabled(false);
                        bt8.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'O') {
                        bt9.setEnabled(false);
                        bt9.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'P') {
                        bt10.setEnabled(false);
                        bt10.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'A') {
                        bt11.setEnabled(false);
                        bt11.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'S') {
                        bt12.setEnabled(false);
                        bt12.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'D') {
                        bt13.setEnabled(false);
                        bt13.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'F') {
                        bt14.setEnabled(false);
                        bt14.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'G') {
                        bt15.setEnabled(false);
                        bt15.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'H') {
                        bt16.setEnabled(false);
                        bt16.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'J') {
                        bt17.setEnabled(false);
                        bt17.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'K') {
                        bt18.setEnabled(false);
                        bt18.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'L') {
                        bt19.setEnabled(false);
                        bt19.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'Z') {
                        bt20.setEnabled(false);
                        bt20.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'X') {
                        bt21.setEnabled(false);
                        bt21.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'C') {
                        bt22.setEnabled(false);
                        bt22.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'V') {
                        bt23.setEnabled(false);
                        bt23.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'B') {
                        bt24.setEnabled(false);
                        bt24.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'N') {
                        bt25.setEnabled(false);
                        bt25.setTextColor(Color.parseColor("#33cc00"));
                    } else if (ch == 'M') {
                        bt26.setEnabled(false);
                        bt26.setTextColor(Color.parseColor("#33cc00"));
                    }
                }
                if (correctlytyped == wordlength) {
                   // Toast.makeText(getApplicationContext(), "you win  hhh "+photo, Toast.LENGTH_LONG).show();
                    score = score + 10;
                    tvscore.setText("SCORE " + score);
                    t1.speak(word, TextToSpeech.QUEUE_FLUSH, null);
                    Intent in = new Intent(this, MissionSuccessDialogActivity.class);
                    in.putExtra("photo", photo);
                    startActivityForResult(in, 10);

                }
            }
        }
    } else {
        wronglytyped++;
        if (ch == 'Q') {
            bt1.setEnabled(false);
            bt1.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'W') {
            bt2.setEnabled(false);
            bt2.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'E') {
            bt3.setEnabled(false);
            bt3.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'R') {
            bt4.setEnabled(false);
            bt4.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'T') {
            bt5.setEnabled(false);
            bt5.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'Y') {
            bt6.setEnabled(false);
            bt6.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'U') {
            bt7.setEnabled(false);
            bt7.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'I') {
            bt8.setEnabled(false);
            bt8.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'O') {
            bt9.setEnabled(false);
            bt9.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'P') {
            bt10.setEnabled(false);
            bt10.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'A') {
            bt11.setEnabled(false);
            bt11.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'S') {
            bt12.setEnabled(false);
            bt12.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'D') {
            bt13.setEnabled(false);
            bt13.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'F') {
            bt14.setEnabled(false);
            bt14.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'G') {
            bt15.setEnabled(false);
            bt15.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'H') {
            bt16.setEnabled(false);
            bt16.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'J') {
            bt17.setEnabled(false);
            bt17.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'K') {
            bt18.setEnabled(false);
            bt18.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'L') {
            bt19.setEnabled(false);
            bt19.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'Z') {
            bt20.setEnabled(false);
            bt20.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'X') {
            bt21.setEnabled(false);
            bt21.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'C') {
            bt22.setEnabled(false);
            bt22.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'V') {
            bt23.setEnabled(false);
            bt23.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'B') {
            bt24.setEnabled(false);
            bt24.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'N') {
            bt25.setEnabled(false);
            bt25.setTextColor(Color.parseColor("#ff3333"));
        } else if (ch == 'M') {
            bt26.setEnabled(false);
            bt26.setTextColor(Color.parseColor("#ff3333"));
        }
        // Toast.makeText(getApplicationContext(), "hang value " + wronglytyped, Toast.LENGTH_LONG).show();
        if(wronglytyped==1){
            img.setImageResource(R.drawable.hanged1);
        }
        else if(wronglytyped==2){
            img.setImageResource(R.drawable.hanged2);
        }
        else if(wronglytyped==3){
            img.setImageResource(R.drawable.hanged3);
        }
        else if(wronglytyped==4){
            img.setImageResource(R.drawable.hanged4);
        }
        else  if(wronglytyped==5){
            img.setImageResource(R.drawable.hanged5);
        }
        else   if (wronglytyped >= 6) {
            img.setImageResource(R.drawable.hanged6);
            // Toast.makeText(getApplicationContext(), "Mission Fail/ Hanged", Toast.LENGTH_LONG).show();
            Intent in = new Intent(this, MissionFailDialogActivity.class);
            startActivityForResult(in, 10);
        }
        else{

        }
    }

}
    public void buttonclick(View view) {

        if (view.getId() == R.id.bt1) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
         buttonlogic(t,ch);

        } else if (view.getId() == R.id.bt2) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt3) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt4) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt5) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt6) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt7) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt8) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt9) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt10) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt11) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt12) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt13) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt14) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt15) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt16) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt17) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt18) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt19) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt20) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt21) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt22) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt23) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt24) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt25) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        } else if (view.getId() == R.id.bt26) {
            Button b=(Button)view;
            String t=b.getText().toString();
            t=t.toUpperCase();
            char ch=t.charAt(0);
            buttonlogic(t,ch);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("MYMSG", "in on start");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("MYMSG", "in on resume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("MYMSG", "in on pause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("MYMSG", "in on stop");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("MYMSG", "in on restart");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("MYMSG", "in on destroy");
    }

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
          ad.show();
    }
}


