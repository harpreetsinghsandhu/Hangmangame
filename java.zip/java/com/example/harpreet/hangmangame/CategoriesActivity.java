package com.example.harpreet.hangmangame;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class CategoriesActivity extends AppCompatActivity {
    ArrayList<categories> al = new ArrayList<categories>();
    myadapter myad;
    ListView lv2;

    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        //getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
               // WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_categories);

        db  = openOrCreateDatabase("MYDB",MODE_PRIVATE,null);
        lv2 = (ListView) (findViewById(R.id.lv2));

            Cursor c = db.rawQuery("select * from categories", null);
            while (c.moveToNext()) {
                int icon = c.getInt(c.getColumnIndex("icon"));
                String cname = c.getString(c.getColumnIndex("cname"));
                al.add(new categories(cname, icon));
            }

        myad = new myadapter();
        lv2.setAdapter(myad);

        lv2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               Intent in=new Intent(getApplicationContext(),GameActivity.class);
                in.putExtra("cname",al.get(position).name);
                startActivity(in);
            }
        });


    }

    class myadapter extends BaseAdapter
    {
        @Override
        public int getCount() {
            return al.size();
        }

        @Override
        public Object getItem(int position) {
            return al.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position*10;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            if(convertView==null) {
                LayoutInflater l = LayoutInflater.from(getApplicationContext());
                convertView = l.inflate(R.layout.single_row, parent, false);
            }
            TextView tv_rn = (TextView) (convertView.findViewById(R.id.tv_rn));
            ImageView img=(ImageView)(convertView.findViewById(R.id.imv1)) ;

            categories s = al.get(position);

            tv_rn.setText(s.name);
            Picasso.with(getApplicationContext()).load(s.img).resize(200,200).centerInside().into(img);

            return convertView;
        }
    }

    public class categories {
        String name;
        int img;

        categories(String name,int img)
        {
            this.name=name;
            this.img = img;
        }




    }
    @Override
    public void onBackPressed() {
       super.onBackPressed();
        Intent in=new Intent(this,MainActivity.class);
        startActivity(in);
    }
}
