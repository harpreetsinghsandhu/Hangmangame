package com.example.harpreet.hangmangame;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;
import java.io.File;
public class MainActivity extends AppCompatActivity {
    SQLiteDatabase db=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        //getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
               // WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);
          db = openOrCreateDatabase("MYDB", MODE_PRIVATE, null);
          storedata();
    }
    public void storedata()
    {
        if(checkForTableExists(db,"categories"))
        {
            // Toast.makeText(getApplication(),"db and table already exists",Toast.LENGTH_LONG).show();
        }
        else {
            db.execSQL("create table if not exists categories (cname VARCHAR(500) PRIMARY KEY , icon INTEGER)");
            int a1=R.drawable.animals;
            int a2=R.drawable.countries;
            int a3=R.drawable.hollywood;
            int a4=R.drawable.flowers;
            int a5=R.drawable.kids;
            int a6=R.drawable.vegetables;
            int a7=R.drawable.dictionary;
            int a8=R.drawable.fruits;
            int a9=R.drawable.justfun;
            int a10=R.drawable.sports;
            int a11=R.drawable.places;
            int a12=R.drawable.humanbody;
            int a13=R.drawable.jobs;
            int a14=R.drawable.furniture;
            int a15=R.drawable.transportation;
            db.execSQL("insert into categories (cname,icon) values('Animals',"+a1+")");
            db.execSQL("insert into categories (cname,icon) values('Countries',"+a2+")");
            db.execSQL("insert into categories (cname,icon) values('Hollywood',"+a3+")");
            db.execSQL("insert into categories (cname,icon) values('Flowers',"+a4+")");
            db.execSQL("insert into categories (cname,icon) values('Kids',"+a5+")");
            db.execSQL("insert into categories (cname,icon) values('Vegetables',"+a6+")");
            db.execSQL("insert into categories (cname,icon) values('Dictionary',"+a7+")");
            db.execSQL("insert into categories (cname,icon) values('Fruits',"+a8+")");
            db.execSQL("insert into categories (cname,icon) values('Just Fun',"+a9+")");
            db.execSQL("insert into categories (cname,icon) values('Sports',"+a10+")");
            db.execSQL("insert into categories (cname,icon) values('Places',"+a11+")");
            db.execSQL("insert into categories (cname,icon) values('Human Body',"+a12+")");
            db.execSQL("insert into categories (cname,icon) values('Jobs',"+a13+")");
            db.execSQL("insert into categories (cname,icon) values('Furniture',"+a14+")");
            db.execSQL("insert into categories (cname,icon) values('Transportation',"+a15+")");
            int b1=R.drawable.tigerjpg;
            int b2=R.drawable.elephant;
            int b3=R.drawable.dog;
            int b4=R.drawable.snake;
            int b5=R.drawable.cat;
            int b6=R.drawable.india;
            int b7=R.drawable.america;
            int b8=R.drawable.canada;
            int b9=R.drawable.australia;
            int b10=R.drawable.uk;
            int c1=R.drawable.twins;
            int c2=R.drawable.kelly;
            int c3=R.drawable.connery;
            int c4=R.drawable.diane;
            int c5=R.drawable.hanks;
            db.execSQL("create table if not exists words (word VARCHAR(500) PRIMARY KEY,suggest VARCHAR(1000),photo INTEGER,cname VARCHAR(500) , FOREIGN KEY ('cname') REFERENCES 'categories' ('cname'))");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Tiger','animal whose  diet ordinarily consists of about 50% wild boar meat.get their paws on some wild boar',"+b1+",'Animals')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Elephant','Largest land animals on Earth. They have characteristic long noses, or trunks; large, floppy ears, and wide, thick legs',"+b2+",'Animals')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Dog','animal having an extraordinarily acute sense of smell,it is about a million times more sensitive than that of people',"+b3+",'Animals')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Snake',' Animal Whose  bite  is a medical emergency because it can be deadly if not treated quickly.',"+b4+",'Animals')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Cat','An Animal  which can be inquisitive, friendly, playful, active, loving and independent.',"+b5+",'Animals')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('India','A land of dreams in which about a seventh of our world population resides having one of the richest and most vivid histories.',"+b6+",'Countries')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('America','The largest economy in the world. the worlds most powerful nation after World War II.',"+b7+",'Countries')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Canada','Country which produce around 80 per cent of the worlds maple syrup . famous for is its delicious contribution to your pancakes',"+b8+",'Countries')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Australia','Is also the worlds driest continent. ...having  some of the worlds oldest geological features',"+b9+",'Countries')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('UnitedKingdom','The worlds fifth biggest economy. a permanent member of the UN Security Council',"+b10+",'Countries')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Twins','In which 80s film did Arnold Schwarzenegger play Danny De Vitos brother',"+c1+",'Hollywood')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Kelly','Which actress Grace became Princess of Monaco',"+c2+",'Hollywood')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Connery','Which Scottish actor Sean has an actor son Jason?',"+c3+",'Hollywood')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Diane','Which actress Keaton starred in Father of the Bride II',"+c4+",'Hollywood')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Hanks','Which actor Tom won Oscars in 1993 and again in 1994',"+c5+",'Hollywood')");
int c6=R.drawable.rose;
int c7=R.drawable.orchid;
int c8=R.drawable.callalily;
int c9=R.drawable.petal;
int c10=R.drawable.rafflasia;
            db.execSQL("insert into words (word,suggest,photo,cname) values('Rose','Which cut flower is the most popular for purchase',"+c6+",'Flowers')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Orchid','Which flower has the smallest seeds',"+c7+",'Flowers')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Callalily','Which flower symbolically means beauty',"+c8+",'Flowers')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Petals','Which part of the flower is the corolla',"+c9+",'Flowers')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Rafflasia','Which is the largest flower of the world',"+c10+",'Flowers')");

            int d6=R.drawable.red;
            int d7=R.drawable.car;
            int d8=R.drawable.cow;
            int d9=R.drawable.milk;
            int d10=R.drawable.christmas;
            db.execSQL("insert into words (word,suggest,photo,cname) values('Red','What colour are apples',"+d6+",'Kids')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Car','Can you name a word that starts with the letter C',"+d7+",'Kids')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Cow','What animal goes Moo',"+d8+",'Kids')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Milk','What do you drink that comes from a cow',"+d9+",'Kids')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Christmas',' During which festival does Santa come to visit',"+d10+",'Kids')");

            int e6=R.drawable.broccoli;
            int e7=R.drawable.onion;
            int e8=R.drawable.beetroot;
            int e9=R.drawable.potato;
            int e10=R.drawable.carrots;
            db.execSQL("insert into words (word,suggest,photo,cname) values('Broccoli','What is the name of the vegetable that is also a flower ',"+e6+",'Vegetables')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Onion','What is the main ingredient of sauce Lyonnaise',"+e7+",'Vegetables')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Beetroot','The main ingredient in Borsch is what ',"+e8+",'Vegetables')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('potato','Munster plum is what type of food',"+e9+",'Vegetables')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Carrot','A dish served A la Crecy is garnished with what ',"+e10+",'Vegetables')");


            int f6=R.drawable.dotage;
            int f7=R.drawable.incorrigible;
            int f8=R.drawable.archaeology;
            int f9=R.drawable.intellectual;
            int f10=R.drawable.stickler;
            db.execSQL("insert into words (word,suggest,photo,cname) values('Dotage','Expreme old age when a man behaves like a fool ',"+f6+",'Dictionary')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Incorrigible','That which cannot be corrected',"+f7+",'Dictionary')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Archaeology','The study of ancient societies',"+f8+",'Dictionary')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Intellectual','A person of good understanding knowledge and reasoning power',"+f9+",'Dictionary')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Stickler','A person who insists on something ',"+f10+",'Dictionary')");




            int g6=R.drawable.grapes;
            int g7=R.drawable.blueberries;
            int g8=R.drawable.apple;
            int g9=R.drawable.banana;
            int g10=R.drawable.fructose;
            db.execSQL("insert into words (word,suggest,photo,cname) values('Grape','A ___ is an example of a summer fruit. ',"+g6+",'Fruits')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Blueberries','Which fruit is of better quality when it is stored in cool dry place where moisture cant get to it',"+g7+",'Fruits')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Apple','Gala and Granny Smith are varieties of ____.',"+g8+",'Fruits')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Banana','A ____ is an example of a tropical fruit. ',"+g9+",'Fruits')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Fructose','What is the natural form of sugar found in fruit?',"+g10+",'Fruits')");

            int h6=R.drawable.drambuie;
            int h7=R.drawable.dracula;
            int h8=R.drawable.insulin;
            int h9=R.drawable.sayonara;
            int h10=R.drawable.hovercraft;
            db.execSQL("insert into words (word,suggest,photo,cname) values('Drambuie','What is the Scottish drink made from whisky and heather honey called?  ',"+h6+",'Just Fun')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Dracula','Name the historical prince whose name was used by Bram Stoker in his famous novel.',"+h7+",'Just Fun')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Insulin','Which hormone controls the supply of sugar between muscles and blood? ',"+h8+",'Just Fun')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Sayonara','In Japanese, what is the word for goodbye? ',"+h9+",'Just Fun')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Hovercraft','What did Sir Christopher Cockerell invent? ',"+h10+",'Just Fun')");

            int i6=R.drawable.boxing;
            int i7=R.drawable.swimming;
            int i8=R.drawable.golf;
            int i9=R.drawable.cricket;
            int i10=R.drawable.badminton;
            db.execSQL("insert into words (word,suggest,photo,cname) values('Boxing','In which sports is the participant called pugilist?  ',"+i6+",'Sports')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Swimming','The term butterfly stroke is referred to in which sports?  ',"+i7+",'Sports')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Golf','In which sports the term putting is used?  ',"+i8+",'Sports')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Cricket','The term beamer is associated with?  ',"+i9+",'Sports')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Badminton','Thomas cup is related to?  ',"+i10+",'Sports')");


            int j6=R.drawable.lebanon;
            int j7=R.drawable.brazil;
            int j8=R.drawable.france;
            int j9=R.drawable.indonesia;
            int j10=R.drawable.uae;
            db.execSQL("insert into words (word,suggest,photo,cname) values('Lebanon','Baalbek & Its Ruined Temples is located in which country? ',"+j6+",'Places')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Brazil','Christ The Redeemer Statue on Corcovado Mountain is located in which country? ',"+j7+",'Places')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('France','Mont Saint-Michel is located in which country?',"+j8+",'Places')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Indonesia','The famous landmark of Borobudur Temple in Magelang is located in which country? ',"+j9+",'Places')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('UnitedArabEmirates','Burj Al Arab is located in which country? ',"+j10+",'Places')");

            int k6=R.drawable.cerebrum;
            int k7=R.drawable.iron;
            int k8=R.drawable.lachrymal;
            int k9=R.drawable.liver;
            int k10=R.drawable.skin;
            db.execSQL("insert into words (word,suggest,photo,cname) values('Cerebrum','The Largest part of human brain is? ',"+k6+",'Human Body')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Iron','The main constituent of hemoglobin is ? ',"+k7+",'Human Body')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Lachrymal','Which gland secrete tears?',"+k8+",'Human Body')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('liver','Which is the largest gland in human body? ',"+k9+",'Human Body')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Skin','Which is the largest organ in human body? ',"+k10+",'Human Body')");

            int l6=R.drawable.address;
            int l7=R.drawable.nationality;
            int l8=R.drawable.two;
            int l9=R.drawable.latin;
            int l10=R.drawable.bank;
            db.execSQL("insert into words (word,suggest,photo,cname) values('Address','Which  is not mentioned in a resume? ',"+l6+",'Jobs')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Nationality',' Which  is not mentioned in a job description CV ',"+l7+",'Jobs')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Two','How many references are usually given in a bio data?',"+l8+",'Jobs')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('latin','Curriculum vitae is a ____ word.',"+l9+",'Jobs')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Bank',' What is the best way to seek information regarding finance? ',"+l10+",'Jobs')");


            int m6=R.drawable.sweet;
            int m7=R.drawable.black;
            int m8=R.drawable.awning;
            int m9=R.drawable.staircase;
            int m10=R.drawable.eves;
            db.execSQL("insert into words (word,suggest,photo,cname) values('Sweet','How should the smell of a freshly cut timber be?',"+m6+",'Furniture')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Black',' Anticorrosive paint is ___________ in colour',"+m7+",'Furniture')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Awning',' Synthetic rubber paints are prepared from',"+m8+",'Furniture')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Staircase','The space housing the stairs is called',"+m9+",'Furniture')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Eves',' The lowest edge of sloping surface of roof is called ',"+m10+",'Furniture')");


            int n6=R.drawable.roadway;
            int n7=R.drawable.weather;
            int n8=R.drawable.dynamic;
            int n9=R.drawable.finanacial;
            int n10=R.drawable.arboriculture;
            db.execSQL("insert into words (word,suggest,photo,cname) values('Roadway','Which is the most flexible type of transportation available?',"+n6+",'Transportation')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Weather',' Traffic forecast is not influenced by',"+n7+",'Transportation')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Dynamic',' The traffic flow is',"+n8+",'Transportation')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Financial','The revenue from road transport sector is studied in which type of studies?',"+n9+",'Transportation')");
            db.execSQL("insert into words (word,suggest,photo,cname) values('Arboriculture','The planting of trees along road side is called.',"+n10+",'Transportation')");


            db.execSQL("create table if not exists scoretable (sid INTEGER PRIMARY KEY AUTOINCREMENT,userscore INTEGER)");
            //Toast.makeText(getApplication(),"new db and table created",Toast.LENGTH_LONG).show();
        }
    }
    private boolean checkForTableExists(SQLiteDatabase db, String table){
        String sql = "SELECT name FROM sqlite_master WHERE type='table' AND name='"+table+"'";
        Cursor mCursor = db.rawQuery(sql, null);
        if (mCursor.getCount() > 0) {
            return true;
        }
        mCursor.close();
        return false;
    }
    public void opencategories(View view){
        Intent in=new Intent(this,CategoriesActivity.class);
        startActivity(in);
    }
    @Override
    public void onBackPressed() {
        Intent a = new Intent(Intent.ACTION_MAIN);
        a.addCategory(Intent.CATEGORY_HOME);
        a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(a);

    }
    public void share(View view)
    {
        int score=0;
        Cursor cus = db.rawQuery("select * from scoretable", null);
        while(cus.moveToNext()) {
            score = cus.getInt(cus.getColumnIndex("userscore"));
        }
        String message = "Download Hangman Game From PlayStore And Break My Challenge .My Highest Score is "+score+".";
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT, message);
        startActivity(Intent.createChooser(share, "Title of the dialog the system will open"));
    }
}
